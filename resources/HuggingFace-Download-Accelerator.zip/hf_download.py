"""
@File         :hf_download.py
@Description  :Download huggingface models and datasets from mirror site.
"""

import os
import huggingface_hub
from huggingface_hub import list_repo_files

def hf_download(model, dataset, token, include, exclude, save_dir, use_hf_transfer, use_mirror):
    if use_hf_transfer:
        os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "1"
    
    if use_mirror:
        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
    
    token_option = f"--token {token}" if token else ""
    include_option = f"--include {include}" if include else ""
    exclude_option = f"--exclude {exclude}" if exclude else ""
    
    if model:
        model_name = model.split("/")
        save_path = os.path.join(save_dir, f"models--{model_name[0]}--{model_name[1]}") if len(model_name) > 1 else os.path.join(save_dir, f"models--{model_name[0]}")
        save_dir_option = f"--local-dir {save_path}" if save_dir else ""

        download_shell = f"huggingface-cli download {token_option} {include_option} {exclude_option} --local-dir-use-symlinks False --resume-download {model} {save_dir_option}"
        os.system(download_shell)

    elif dataset:
        dataset_name = dataset.split("/")
        save_path = os.path.join(save_dir, f"datasets--{dataset_name[0]}--{dataset_name[1]}") if len(dataset_name) > 1 else os.path.join(save_dir, f"datasets--{dataset_name[0]}")
        save_dir_option = f"--local-dir {save_path}" if save_dir else ""

        download_shell = f"huggingface-cli download {token_option} {include_option} {exclude_option} --local-dir-use-symlinks False --resume-download --repo-type dataset {dataset} {save_dir_option}"
        os.system(download_shell)

def list_files(repo_id, repo_type):
    try:
        return list_repo_files(repo_id=repo_id, repo_type=repo_type)
    except Exception as e:
        print(f"Error listing files for {repo_id}: {str(e)}")
        return []