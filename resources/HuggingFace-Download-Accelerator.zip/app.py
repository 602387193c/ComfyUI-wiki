import gradio as gr
from hf_download import hf_download, list_files

def update_file_list(repo_id, repo_type):
    files = list_files(repo_id, repo_type)
    return gr.update(choices=files, value=files)

def download_model(model, token, file_list, exclude, save_dir, use_hf_transfer, use_mirror):
    include = " ".join(file_list)
    hf_download(model, None, token, include, exclude, save_dir, use_hf_transfer, use_mirror)
    return "模型下载完成!"

def download_dataset(dataset, token, dataset_file_list, exclude, save_dir, use_hf_transfer, use_mirror): 
    include = " ".join(dataset_file_list)
    hf_download(None, dataset, token, include, exclude, save_dir, use_hf_transfer, use_mirror)
    return "数据集下载完成!"

with gr.Blocks() as demo:
    gr.Markdown("# HuggingFace模型和数据集高速下载")
    with gr.Tab("下载模型"):
        model = gr.Textbox(label="模型名称")
        file_list = gr.CheckboxGroup(label="可下载文件", interactive=True)
        model.change(fn=update_file_list, inputs=[model, gr.Textbox(visible=False, value="model")], outputs=file_list)
        token = gr.Textbox(label="HuggingFace Access Token (可选)")
        with gr.Row():
            exclude = gr.Textbox(label="忽略下载文件 (可选)")
        save_dir = gr.Textbox(label="保存路径 (可选)")
        use_hf_transfer = gr.Checkbox(label="使用hf_transfer加速下载", value=True)
        use_mirror = gr.Checkbox(label="从HuggingFace镜像站下载", value=True)
        download_model_btn = gr.Button("开始下载模型")
        download_model_btn.click(fn=download_model, inputs=[model, token, file_list, exclude, save_dir, use_hf_transfer, use_mirror], outputs=gr.Textbox(label="模型下载结果"))

    with gr.Tab("下载数据集"):
        dataset = gr.Textbox(label="数据集名称") 
        dataset_file_list = gr.CheckboxGroup(label="可下载文件", interactive=True)
        dataset.change(fn=update_file_list, inputs=[dataset, gr.Textbox(visible=False, value="dataset")], outputs=dataset_file_list)
        dataset_token = gr.Textbox(label="HuggingFace Access Token (可选)")
        with gr.Row():
            dataset_exclude = gr.Textbox(label="忽略下载文件 (可选)")
        dataset_save_dir = gr.Textbox(label="保存路径 (可选)") 
        dataset_use_hf_transfer = gr.Checkbox(label="使用hf_transfer加速下载", value=True)
        dataset_use_mirror = gr.Checkbox(label="从HuggingFace镜像站下载", value=True)

        download_dataset_btn = gr.Button("开始下载数据集")
        download_dataset_btn.click(fn=download_dataset, inputs=[dataset, dataset_token, dataset_file_list, dataset_exclude, dataset_save_dir, dataset_use_hf_transfer, dataset_use_mirror], outputs=gr.Textbox(label="数据集下载结果"))

demo.launch()